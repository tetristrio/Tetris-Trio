from tt_game import gameSetup

s = gameSetup()

while s.running:
    s.curr_menu.display_menu()
    s.game_loop()
