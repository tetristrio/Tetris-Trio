# File just calls game file and starts it
# Excute File to begin the application
from tt_game import gameSetup

s = gameSetup()

while s.running:
    s.curr_menu.display_menu()
    s.game_loop()
