# Imports to run menu
import pygame
from pygame_menu import *
# Import needed for tetris game
import random
# Later used to stall display of game until user enters start game
runGame = 0



class gameSetup():
    def __init__(self):
        pygame.init()
        # Labeling varriables used in later truth statements
        self.running, self.playing = True, False
        # Labeling various key presses 
        self.UP_KEY, self.DOWN_KEY, self.START_KEY, self.BACK_KEY = False, False, False, False
        # Setting dimensions of display to the specs of RaspPi
        self.DISPLAY_W, self.DISPLAY_H = 800, 480
        self.display = pygame.Surface((self.DISPLAY_W,self.DISPLAY_H))
        self.window = pygame.display.set_mode(((self.DISPLAY_W,self.DISPLAY_H)))
        # Pygame's default font
        self.font_name = pygame.font.get_default_font()
        # Defining Colors Based on RGB #'s for easier call back
        self.BLUE, self.PURPLE, self.BLACK, self.WHITE = (0, 255, 255), (255, 0, 255), (0, 0, 0), (255, 255, 255)
        self.main_menu = MainMenu(self)
        self.options = OptionsMenu(self)
        self.credits = CreditsMenu(self)
        self.curr_menu = self.main_menu
        
    def game_loop(self):
        while self.playing:
            self.check_events()
            if self.START_KEY:
                self.playing= False
            # This is the check that calls the game file and starts it once user presses
            # enter on start
            runGame = 1
            if runGame == 1:
                # Tetris game file and function to run it
                from TitanicTetris import runTT
            # Resets screen and checks for update status
            self.display.fill(self.BLACK)
            self.window.blit(self.display, (0,0))
            pygame.display.update()
            # Refreshes key status back to False
            self.reset_keys()



    def check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Checking running / playing and setting back to original state
                self.running, self.playing = False, False
                self.curr_menu.run_display = False
            # Different Key press states ; checks
            # Changing from False --> True to establish the key press
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    self.START_KEY = True
                if event.key == pygame.K_BACKSPACE:
                    self.BACK_KEY = True
                if event.key == pygame.K_DOWN:
                    self.DOWN_KEY = True
                if event.key == pygame.K_UP:
                    self.UP_KEY = True

    def reset_keys(self):
        # Resets the keys
        self.UP_KEY, self.DOWN_KEY, self.START_KEY, self.BACK_KEY = False, False, False, False

    def draw_text(self, text, size, x, y ):
        font = pygame.font.Font(self.font_name,size)
        # Text function with previous defined color off rgb system
        text_surface = font.render(text, True, self.PURPLE)
        text_rect = text_surface.get_rect()
        # Defines center of text
        text_rect.center = (x,y)
        self.display.blit(text_surface,text_rect)
