from tkinter import *
root = Tk()

canvas = Canvas(root,width=800, height=480)
canvas.pack()

img = PhotoImage(file="Tetris GUI/title.gif")
canvas.create_image(0,0,anchor=NW,image=img)


root.mainloop()
